# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#      http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Utilites for mutual TLS."""

from os import getenv

from google.auth import exceptions
from google.auth.transport import _mtls_helper


def has_default_client_cert_source(include_context_aware=True):
    """Check if default client SSL credentials exists on the device.

    Args:
       include_context_aware (bool): include_context_aware indicates if context_aware
       path location will be checked or should it be skipped.

    Returns:
        bool: indicating if the default client cert source exists.
    """
    if (
        include_context_aware
        and _mtls_helper._check_config_path(_mtls_helper.CONTEXT_AWARE_METADATA_PATH)
        is not None
    ):
        return True
    if (
        _mtls_helper._check_config_path(
            _mtls_helper.CERTIFICATE_CONFIGURATION_DEFAULT_PATH
        )
        is not None
    ):
        return True
    cert_config_path = getenv("GOOGLE_API_CERTIFICATE_CONFIG")
    if (
        cert_config_path
        and _mtls_helper._check_config_path(cert_config_path) is not None
    ):
        return True
    return False


def default_client_cert_source():
    """Get a callback which returns the default client SSL credentials.

    Returns:
        Callable[[], [bytes, bytes]]: A callback which returns the default
            client certificate bytes and private key bytes, both in PEM format.

    Raises:
        google.auth.exceptions.DefaultClientCertSourceError: If the default
            client SSL credentials don't exist or are malformed.
    """
    if not has_default_client_cert_source(include_context_aware=True):
        raise exceptions.MutualTLSChannelError(
            "Default client cert source doesn't exist"
        )

    def callback():
        try:
            _, cert_bytes, key_bytes = _mtls_helper.get_client_cert_and_key()
        except (OSError, RuntimeError, ValueError) as caught_exc:
            new_exc = exceptions.MutualTLSChannelError(caught_exc)
            raise new_exc from caught_exc

        return cert_bytes, key_bytes

    return callback


def default_client_encrypted_cert_source(cert_path, key_path):
    """Get a callback which returns the default encrpyted client SSL credentials.

    Args:
        cert_path (str): The cert file path. The default client certificate will
            be written to this file when the returned callback is called.
        key_path (str): The key file path. The default encrypted client key will
            be written to this file when the returned callback is called.

    Returns:
        Callable[[], [str, str, bytes]]: A callback which generates the default
            client certificate, encrpyted private key and passphrase. It writes
            the certificate and private key into the cert_path and key_path, and
            returns the cert_path, key_path and passphrase bytes.

    Raises:
        google.auth.exceptions.DefaultClientCertSourceError: If any problem
            occurs when loading or saving the client certificate and key.
    """
    if not has_default_client_cert_source(include_context_aware=True):
        raise exceptions.MutualTLSChannelError(
            "Default client encrypted cert source doesn't exist"
        )

    def callback():
        try:
            (
                _,
                cert_bytes,
                key_bytes,
                passphrase_bytes,
            ) = _mtls_helper.get_client_ssl_credentials(generate_encrypted_key=True)
            with open(cert_path, "wb") as cert_file:
                cert_file.write(cert_bytes)
            with open(key_path, "wb") as key_file:
                key_file.write(key_bytes)
        except (exceptions.ClientCertError, OSError) as caught_exc:
            new_exc = exceptions.MutualTLSChannelError(caught_exc)
            raise new_exc from caught_exc

        return cert_path, key_path, passphrase_bytes

    return callback


def should_use_client_cert():
    """Returns boolean for whether the client certificate should be used for mTLS.

    This is a wrapper around _mtls_helper.check_use_client_cert().
    If GOOGLE_API_USE_CLIENT_CERTIFICATE is set to true or false, a corresponding
    bool value will be returned
    If GOOGLE_API_USE_CLIENT_CERTIFICATE is unset, the value will be inferred by
    reading a file pointed at by GOOGLE_API_CERTIFICATE_CONFIG, and verifying it
    contains a "workload" section. If so, the function will return True,
    otherwise False.

    Returns:
       bool: indicating whether the client certificate should be used for mTLS.
    """
    return _mtls_helper.check_use_client_cert()
